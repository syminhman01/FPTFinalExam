# Nguồn tham khảo đối chiếu

Các liên kết dưới đây hỗ trợ kiểm tra thuật ngữ và các câu dễ nhầm. Không có khóa chấm chính thức trong file nguồn. Đáp án được lựa chọn bằng phân tích câu hỏi và phương án; các trường hợp diễn đạt chưa chặt được ghi chú riêng.

- **S01** - [Lumen Learning - Patterns of Thought](https://courses.lumenlearning.com/suny-jeffersoncc-collegesuccess-lumen1/chapter/patterns-of-thought/): Thinking, Thought và các mức Bloom.
- **S02** - [Lumen Learning - Using Technology](https://courses.lumenlearning.com/waymaker-collegesuccess/chapter/text-critical-and-creative-thinking-with-technology/): Sơ đồ công nghệ hỗ trợ Bloom, discussion boards, wiki.
- **S03** - [Lumen Learning - Problem-Solving](https://courses.lumenlearning.com/waymaker-collegesuccess/chapter/text-problem-solving/): Tư duy phản biện và giải quyết vấn đề.
- **S04** - [IGNOU - Learning Skills for Adults, Block 2](https://www.egyankosh.ac.in/bitstream/123456789/106477/3/Block-2.pdf): Bảng Define the problem và Identify available solutions, trang in 72.
- **S05** - [Lumen Learning - Creative Thinking in Your Education](https://courses.lumenlearning.com/waymaker-collegesuccess/chapter/text-creative-thinking-in-your-education/): Drawing, Sensing và những ví dụ sáng tạo trong học tập.
- **S06** - [Lumen Learning - Solving Problems Creatively](https://courses.lumenlearning.com/wm-collegesuccess-2/chapter/text-problem-solving-with-creative-thinking/): Sáng tạo, giải quyết vấn đề, ngộ nhận và sự thật.
- **S07** - [OpenStax - Principles of Management 15.6: Multicultural Teams](https://openstax.org/books/principles-management/pages/15-6-multicultural-teams): Cognitive complexity, rào cản ngôn ngữ, managerial intervention.
- **S08** - [OpenStax - Organizational Behavior 12.3: Leader Emergence](https://openstax.org/books/organizational-behavior/pages/12-3-leader-emergence): Lãnh đạo chính thức và phi chính thức.
- **S09** - [University of Minnesota - Stages of Career Development](https://www.takingcharge.csh.umn.edu/activities/stages-career-development): Autonomy and Tentative Choices: 18-26 tuổi.
- **S10** - [University of Kansas - Defining Teams and Groups](https://opentext.ku.edu/teams/chapter/teams-and-groups/): Các loại đội, tuyến báo cáo, contract team và span of control.
- **S11** - [Pikes Peak State College - Defining Power](https://pressbooks.ccconline.org/ppsccom2220groupcommunication/chapter/7-1-defining-power/): Phân biệt power-over, power-with, power-from-within.
- **S12** - [Business Communication for Success - Feedback as an Opportunity](https://pressbooks.openeducationalberta.ca/saitbusinesscommunication/chapter/8-3-feedback-as-an-opportunity/): Interpretive feedback, supportive feedback.
- **S13** - [Business Communication for Success - Meeting the Listener's Basic Needs](https://pressbooks.openeducationalberta.ca/saitbusinesscommunication/chapter/14-4-meeting-the-listeners-basic-needs/): Bốn lý do tham gia giao tiếp trong bảng 14.1.
- **S14** - [University of Minnesota - Organizational Behavior](https://open.lib.umn.edu/organizationalbehavior/open/download?type=pdf): Ý nghĩa khác nhau theo văn hóa của cử chỉ OK.
- **S15** - [Lumen Learning - Stress](https://courses.lumenlearning.com/suny-collegesuccess-lumen1/chapter/stress/): Quản lý thời gian, hỗ trợ xã hội và tránh tự cô lập.
- **S16** - [Mayo Clinic - Chronic stress puts your health at risk](https://www.mayoclinic.org/healthy-lifestyle/stress-management/in-depth/stress/art-20046037): Tác động của căng thẳng kéo dài.
- **S17** - [University of Warwick - Team Development Guide](https://warwick.ac.uk/services/lmd/teamdevelopmentguide/): Các dấu hiệu Forming, Storming, Norming, Performing, Adjourning.
- **S18** - [Technical Writing Essentials - Feasibility and Recommendation Reports](https://openlibrary-repo.ecampusontario.ca/jspui/bitstream/123456789/636/6/Technical-Writing-Essentials-1563391799.html): Phân biệt kết luận và phương án hành động được kiến nghị.
- **S19** - [Blueprint for Success in College and Career](https://openlibrary-repo.ecampusontario.ca/jspui/bitstream/123456789/560/4/Blueprint-for-Success-in-College-and-Career-1543940326.html): Các câu hỏi mở của tư duy sáng tạo.
- **S20** - [Business Proposals - Business Writing: Theory, Process, and Application](https://pressbooks.pub/businesswriting/chapter/9-3-business-proposals/): Các phần của proposal: Background, Market Analysis, Timeline.
