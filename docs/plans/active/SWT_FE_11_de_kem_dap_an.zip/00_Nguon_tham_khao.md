# Nguồn tham khảo đối chiếu SWT301

Các nguồn sơ cấp dưới đây hỗ trợ thuật ngữ và phương pháp. Các phép tính coverage, phân vùng, BVA và đọc sơ đồ được phân tích trực tiếp trên đề cung cấp. Câu dùng khái niệm/chuẩn cũ được xử lý theo ngữ cảnh, kèm chú thích khi cần. Không sử dụng một khóa chấm chính thức của trường.

- **S01** - [ISTQB CTFL 2018 v3.1.1, mục 1-2](https://istqb.org/wp-content/uploads/2024/11/ISTQB-CTFL_Syllabus_2018_v3.1.1.pdf): Nền tảng, test levels, test types, confirmation và regression.
- **S02** - [ISTQB CTFL 2018 v3.1.1, mục 3](https://istqb.org/wp-content/uploads/2024/11/ISTQB-CTFL_Syllabus_2018_v3.1.1.pdf#page=45): Static testing, review process, roles, review types.
- **S03** - [ISTQB CTFL 2018 v3.1.1, mục 4](https://istqb.org/wp-content/uploads/2024/11/ISTQB-CTFL_Syllabus_2018_v3.1.1.pdf#page=55): Equivalence partitioning, BVA, decision table, state transition, coverage và experience-based testing.
- **S04** - [ISTQB CTFL 2018 v3.1.1, mục 5-6](https://istqb.org/wp-content/uploads/2024/11/ISTQB-CTFL_Syllabus_2018_v3.1.1.pdf#page=64): Quản lý, rủi ro, cấu hình, defect reports và công cụ kiểm thử.
- **S05** - [ISTQB CTFL v4.0.1](https://istqb.org/wp-content/uploads/2024/11/ISTQB_CTFL_Syllabus_v4.0.1.pdf): Đối chiếu thuật ngữ hiện đại; branch coverage, BVA hai/ba điểm và whole-team approach.
- **S06** - [BSI - BS 7925 series](https://landingpage.bsigroup.com/LandingPage/Series?UPI=BS+7925): BS 7925-1: Vocabulary; BS 7925-2: Software component testing.
- **S07** - [ISO/IEC 9126-1:2001 - Product quality model](https://www.iso.org/standard/22749.html): Tiêu chuẩn chất lượng sản phẩm được nhắc trong đề cũ; trang ISO ghi trạng thái đã rút/thay thế.
- **S08** - [NIST SP 500-235 - Structured Testing](https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication500-235.pdf): Cyclomatic complexity và basis-path testing.
- **S09** - [IFPUG - Function Point Analysis](https://ifpug.org/ifpug-standards/fpa): Đo kích thước chức năng bằng function points.
- **S10** - [CSTE Common Body of Knowledge](https://www.softwaretestinggenius.com/download/CBOK.pdf): Tài liệu sơ cấp của chương trình CSTE, bản PDF lưu trên trang ngoài: workbench, procedures/standards, defect management và chi phí chất lượng.
- **S11** - [IEEE Technology Navigator - Standards](https://technav.ieee.org/topic/standards/): Vai trò của IEEE, ISO, IEC trong hạ tầng tiêu chuẩn; giải thích sự không chặt chẽ của câu phân loại quốc tế.
